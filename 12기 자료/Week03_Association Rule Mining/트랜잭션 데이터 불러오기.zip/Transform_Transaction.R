install.packages("arules")
library(arules)

# Basket type
tmp_tr <- read.transactions("Transaction_Sample_Basket.csv", format = "basket", sep = ",", rm.duplicates=TRUE)
inspect(tmp_tr)

# Single type
tmp_tr <- read.transactions("Transaction_Sample_Single.csv", format = "single", cols = c(1,2), rm.duplicates=TRUE)
inspect(tmp_tr)

ptm <- proc.time()
rules <- apriori(tmp_tr, parameter = list(minlen = 1, maxlen = 2, support = 0.2, conf = 0.7))
proc.time() - ptm

inspect(sort(rules, by="lift"))
